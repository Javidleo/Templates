﻿using QueryHandling.Abstractions;
using $safeprojectname$.Query.PostAttachmentQueries;
using $safeprojectname$.ViewModel;
using $safeprojectname$.ViewModel.PostAttachment.OutPut;
using System.Linq;
using System.Threading.Tasks;

namespace $safeprojectname$.QueryHandler.PostAttachmentQueryHandlers
{
    public class GetPostAllAttachmentsQueryHandler : IHandleQuery<GetPostAllAttachmentsQuery, PagedViewModel<UserPostAttachmentViewModelOutPut>>
    {
        private readonly IReadDbContext dbContext;
        public GetPostAllAttachmentsQueryHandler(IReadDbContext readDbContext)
        => dbContext = readDbContext;

        public Task<PagedViewModel<UserPostAttachmentViewModelOutPut>> Handle(GetPostAllAttachmentsQuery query)
        {
            var UserPostAttachmentViewModel =
                dbContext.PostAttachmentViewModels.Where(c => c.PostId == query.PostId).Select(c => new UserPostAttachmentViewModelOutPut()
                 {
                     FileName = c.FileName,
                     Id = c.Id,
                     PostAttachmentTitle = c.PostAttachmentTitle
                 });
            var result = PagingUtility.Paginate(query.PageNumber, query.PageSize, UserPostAttachmentViewModel);
            return Task.FromResult(result);
        }
    }
}
