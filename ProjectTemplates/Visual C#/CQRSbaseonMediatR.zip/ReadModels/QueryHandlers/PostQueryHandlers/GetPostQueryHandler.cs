﻿using QueryHandling.Abstractions;
using $safeprojectname$.Query.PostQueries;
using $safeprojectname$.ViewModel.Post;
using $safeprojectname$.ViewModel.Post.OutPut;
using $safeprojectname$.ViewModel.PostAttachment.OutPut;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace $safeprojectname$.QueryHandler.PostQueryHandlers
{
    public class GetPostQueryHandler : IHandleQuery<GetPostQuery, PostViewModelWithContentOutPut>
    {
        private readonly IReadDbContext dbContext;
        public GetPostQueryHandler(IReadDbContext readDbContext)
        => dbContext = readDbContext;

        public Task<PostViewModelWithContentOutPut> Handle(GetPostQuery query)
        {
            PostViewModel postViewModel = dbContext.PostViewModels.Find(query.Id);
            PostViewModelWithContentOutPut result = new();
            if (postViewModel != null)
            {
                if (postViewModel.UserId != query.UserId)
                {
                    postViewModel.VisitCount += 1;
                    dbContext.PostViewModels.Update(postViewModel);
                }

                List<UserPostAttachmentViewModelOutPut> FileAttachments = dbContext.PostAttachmentViewModels.Where(c => c.PostId == query.Id)
                                                                                                    .Select(c => new UserPostAttachmentViewModelOutPut()
                                                                                                    {
                                                                                                        FileName = c.FileName,
                                                                                                        Id = c.Id,
                                                                                                        PostAttachmentTitle = c.PostAttachmentTitle,
                                                                                                        ImageFileThumbnail = c.ImageFileThumbnail,
                                                                                                        ContentType = c.ContentType
                                                                                                    }).ToList();

                result = new()
                {
                    CategoryId = postViewModel.CategoryId,
                    PostContent = postViewModel.PostContent,
                    InsertDate = postViewModel.PersianInsertDate + " " + postViewModel.InsertTime,
                    Id = postViewModel.Id,
                    PostTitle = postViewModel.PostTitle,
                    Tags = postViewModel.Tags,
                    IsPrivate = postViewModel.IsPrivate,
                    IsDraft = postViewModel.IsDraft,
                    VisitCount = postViewModel.VisitCount,
                    GroupId=postViewModel.GroupId,
                    GroupTitle=postViewModel.GroupTitle,
                    SubGroupId=postViewModel.SubGroupId,
                    SubGroupTitle=postViewModel.SubGroupTitle,
                    FileAttachments = FileAttachments
                };
            }
            return Task.FromResult(result);
        }
    }
}
