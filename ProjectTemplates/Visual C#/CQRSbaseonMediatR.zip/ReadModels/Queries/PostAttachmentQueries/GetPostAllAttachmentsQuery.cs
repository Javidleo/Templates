﻿using QueryHandling.Abstractions;
using $safeprojectname$.ViewModel;
using $safeprojectname$.ViewModel.PostAttachment.OutPut;

namespace $safeprojectname$.Query.PostAttachmentQueries
{
    public record GetPostAllAttachmentsQuery(int PageNumber, int PageSize, long PostId) : Query<PagedViewModel<UserPostAttachmentViewModelOutPut>>;
}
