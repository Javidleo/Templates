﻿using QueryHandling.Abstractions;
using $safeprojectname$.ViewModel.PostAttachment.OutPut;

namespace $safeprojectname$.Query.PostAttachmentQueries
{
    public record GetPostAttachmentFileQuery(long PostAttachmentId) : Query<PostAttachmentFileViewModelOutPut>;
}
