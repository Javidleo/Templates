﻿using QueryHandling.Abstractions;
using $safeprojectname$.ViewModel;
using $safeprojectname$.ViewModel.Post.OutPut;

namespace $safeprojectname$.Query.PostQueries
{
    public record GetPostListQuery(int PageNumber, int PageSize, long? CategoryId, long? GroupId, long? SubGroupId, string PostTitle,
                                        string PostContent, string Tags, bool? Private, bool? Draft, string StartDate, string EndDate,
                                        string SortOrder) : Query<PagedViewModel<PostViewModelOutPut>>;
}
