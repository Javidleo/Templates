﻿using QueryHandling.Abstractions;
using $safeprojectname$.ViewModel.Post.OutPut;
using System;

namespace $safeprojectname$.Query.PostQueries
{
    public record GetPostQuery(long Id, Guid UserId) : Query<PostViewModelWithContentOutPut>;
}
