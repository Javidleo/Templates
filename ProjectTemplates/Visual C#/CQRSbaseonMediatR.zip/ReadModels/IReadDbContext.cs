﻿using DomainModel;
using Microsoft.EntityFrameworkCore;
using $safeprojectname$.DomainModel.Document;
using $safeprojectname$.ViewModel.Post;
using $safeprojectname$.ViewModel.PostAttachment;

namespace $safeprojectname$
{
    public interface IReadDbContext
    {
        public DbSet<PostViewModel> PostViewModels { get; set; }
        public DbSet<PostAttachmentViewModel> PostAttachmentViewModels { get; set; }
        public DbSet<DocumentView> DocumentView { get; set; }
    }
}
