﻿using QueryHandling.Abstractions;
using System.Collections.Generic;
using System.Linq;

namespace $safeprojectname$.ViewModel
{
    public class ListViewModel<T> : IAmAViewModel
    {
        public IEnumerable<T> Data { get; set; }

        public ListViewModel(IQueryable<T> AllItems)
        {
            Data = AllItems;
        }
    }
}
