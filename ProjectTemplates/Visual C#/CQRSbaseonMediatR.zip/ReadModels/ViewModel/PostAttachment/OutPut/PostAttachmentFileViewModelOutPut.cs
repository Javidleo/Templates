﻿using QueryHandling.Abstractions;

namespace $safeprojectname$.ViewModel.PostAttachment.OutPut
{
    public class PostAttachmentFileViewModelOutPut : IAmAViewModel
    {
        public long Id { get; set; }

        public byte[] File { get; set; }
    }
}
