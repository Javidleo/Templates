﻿
namespace $safeprojectname$.Abstractions
{
    public interface IAmAViewModel
    {
    }
}
