﻿
namespace $safeprojectname$.Abstractions
{
    public interface Query<TViewModel> where TViewModel : IAmAViewModel
    {
    }
}
