﻿using System.Threading.Tasks;

namespace $safeprojectname$.Abstractions
{
    public interface ICommandBus
    {
        public Task Send<Tcommand>(Tcommand command) where Tcommand : Acommand;
    }
}
