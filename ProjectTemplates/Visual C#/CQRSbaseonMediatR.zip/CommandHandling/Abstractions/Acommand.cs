﻿namespace $safeprojectname$.Abstractions
{
    public record Acommand(long Id);
}
