﻿namespace $safeprojectname$
{
    public interface IUnitOfWork
    {
        int SaveChanges();
    }
}
