﻿using DomainModel;
using Microsoft.EntityFrameworkCore;
using System;
using Microsoft.Data.SqlClient;
using System.Linq;
using System.Collections.Generic;

namespace $safeprojectname$.Repositories
{
    internal class PostAttachmentRepository : Repository
    {
        public PostAttachmentRepository(IWriteDbContext dbContext) : base(dbContext)
        { }

        public string Add(PostAttachment postAttachment)
        {
            SqlParameter relativePath = new("relativePath", System.Data.SqlDbType.NVarChar, 255) { Value = DBNull.Value };
            SqlParameter fileName = new("name", System.Data.SqlDbType.NVarChar, 255) { Value = postAttachment.FileSystemName };
            SqlParameter file = new("stream", System.Data.SqlDbType.VarBinary) { Value = postAttachment.File };
            SqlParameter filePath = new("path_locator", System.Data.SqlDbType.NVarChar, 4000) { Value = DBNull.Value };
            string FilePath = dbContext.DocumentView
                    .FromSqlRaw("EXECUTE dbo.AddDocument @relativePath,@name,@stream,@path_locator", relativePath, fileName, file, filePath)
                    .AsEnumerable().FirstOrDefault().path_locator;

            postAttachment.AddFilePath(FilePath);
            dbContext.PostAttachments.Add(postAttachment);
            return FilePath;
        }

        public void Delete(PostAttachment postAttachment)
        {
            SqlParameter pathLocator = new("path_locator", System.Data.SqlDbType.NVarChar, 4000) { Value = postAttachment.FilePath };
            dbContext.DocumentView.FromSqlRaw("EXECUTE dbo.DelDocument @path_locator", pathLocator);
            dbContext.PostAttachments.Remove(postAttachment);
        }

        public PostAttachment Find(long Id)
        => dbContext.PostAttachments.Find(Id);

        public IEnumerable<PostAttachment> GetByPostId(long postId)
        => dbContext.PostAttachments.Where(c => c.PostId == postId);
    }
}