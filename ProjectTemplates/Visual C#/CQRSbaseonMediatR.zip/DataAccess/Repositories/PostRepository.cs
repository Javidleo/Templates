﻿using DomainModel;
using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using UseCases.RepositoryContracts;

namespace $safeprojectname$.Repositories
{
    public class PostRepository : Repository, IPostRepository
    {
        //private readonly IEventBus eventBus;

        public PostRepository(IWriteDbContext dbContext) : base(dbContext) { }//, IEventBus eventBus) : base(dbContext)
        //=> this.eventBus = eventBus;

        public void Add(Post post)
        {

            dbContext.Posts.Add(post);
            foreach (PostAttachment attachment in post.PostAttachments)
            {
                string FilePath = new PostAttachmentRepository(dbContext).Add(attachment);
                post.AddFile(attachment.Id, FilePath);
            }

            try
            {
                //foreach (var @event in post.Events)
                //{
                //    Task task = eventBus.Publish(@event);
                //    if (task.IsFaulted)
                //        throw task.Exception;
                //}
            }
            catch (Exception)
            {
                throw;
            }
            //post.ClearEvents();

        }

        public void Update(Post post)
        {


            PostAttachmentRepository postAttachmentRepository = new(dbContext);
            dbContext.Posts.Update(post);
            IEnumerable<PostAttachment> attachments = postAttachmentRepository.GetByPostId(post.Id);
            foreach (PostAttachment attachment in post.PostAttachments)
            {
                if (!attachments.Any(c => c.Id == attachment.Id))
                {
                    string FilePath = postAttachmentRepository.Add(attachment);
                    post.AddFile(attachment.Id, FilePath);
                }
            }
            foreach (PostAttachment item in from PostAttachment item in attachments
                                            where !post.PostAttachments.Any(c => c.Id == item.Id)
                                            select item)
            {
                postAttachmentRepository.Delete(item);
            }

            try
            {
                //foreach (var @event in post.Events)
                //{
                //    Task task = eventBus.Publish(@event);
                //    if (task.IsFaulted)
                //        throw task.Exception;
                //}
            }
            catch (Exception)
            {
                throw;
            }
            //post.ClearEvents();
        }

        public void Delete(Post post)
        {
           
            PostAttachmentRepository postAttachmentRepository = new(dbContext);
            foreach (PostAttachment attachment in post.PostAttachments)
                postAttachmentRepository.Delete(attachment);
            dbContext.Posts.Remove(post);

            try
            {
                //foreach (var @event in post.Events)
                //{
                //    Task task = eventBus.Publish(@event);
                //    if (task.IsFaulted)
                //        throw task.Exception;
                //}
            }
            catch (Exception)
            {
                throw;
            }

            //post.ClearEvents();
        }

        public Post Find(long Id)
        => dbContext.Posts.Include(c => c.PostAttachments).FirstOrDefault(c => c.Id == Id);

        public int PostCount(long? categoryId)
        => dbContext.Posts.Count(c => c.CategoryId == categoryId || categoryId == null);
    }
}
