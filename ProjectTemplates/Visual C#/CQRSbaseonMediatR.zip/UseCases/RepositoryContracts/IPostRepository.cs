﻿using DomainModel;

namespace $safeprojectname$.RepositoryContracts
{
    public interface IPostRepository
    {
        public void Add(Post post);

        public void Update(Post post);

        public void Delete(Post post);

        public int PostCount(long? categoryId);

        public Post Find(long Id);
    }
}
