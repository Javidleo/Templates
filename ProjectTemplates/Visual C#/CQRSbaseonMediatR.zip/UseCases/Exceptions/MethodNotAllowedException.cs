﻿using System;

namespace $safeprojectname$.Exceptions
{
    public class MethodNotAllowedException : Exception
    {
        public MethodNotAllowedException(string message) : base(message)
        { }
    }
}
