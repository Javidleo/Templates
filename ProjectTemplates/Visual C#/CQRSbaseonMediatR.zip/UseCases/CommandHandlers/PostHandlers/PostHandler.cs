﻿using CommandHandling.Abstractions;
using DomainModel;
using System;
using System.IO;
using System.Threading.Tasks;
using $safeprojectname$.Commands.PostCommands;
using $safeprojectname$.Exceptions;
using $safeprojectname$.RepositoryContracts;

namespace $safeprojectname$.CommandHandlers.PostHandlers
{
    public class PostHandler : IHandleCommand<PostCommand>
    {
        private readonly IPostRepository posts;
        //private readonly ICategoryRepository Categories;
        //private readonly IGroupRepository Groups;
        public PostHandler(IPostRepository posts)//, ICategoryRepository Categories, IGroupRepository groups)
        {
            this.posts = posts;
            //this.Categories = Categories;
            //this.Groups = groups;
        }

        public Task Handle(PostCommand command)
        {
            //if (command.CategoryId != null)
            //    if (Categories.Find(command.CategoryId.Value) == null)
            //        throw new NotFoundException("دسته بندی پیدا نشد.");

            /////Karani
            //if (command.GroupId != null)
            //    if (Groups.GetById(command.GroupId.Value) == null)
            //        throw new NotFoundException("گروه پیدا نشد.");

            //if (command.SubGroupId != null)
            //    if (!Groups.DoesSubGroupExist(command.GroupId.Value,command.SubGroupId.Value))
            //        throw new NotFoundException("زیرگروه پیدا نشد.");
            ///Karani

            if (command.IsDraft == true && command.IsPrivate == true)
                throw new BadRequestException("پست خصوصی نمی تواند به صورت پیش نویس ذخیره شود.");

            Post post = Post.DefinePost(command.PostTitle, command.PostContent, command.CategoryId, command.UserId,
                command.Tags, command.IsPrivate, command.IsDraft,command.GroupId,command.SubGroupId);
            foreach (PostAttachmentFileDataStructure File in command.AttachmentList)
            {
                using Stream stream = File.File.OpenReadStream();
                BinaryReader reader = new(stream);
                byte[] file = reader.ReadBytes(Convert.ToInt32(File.File.Length));
                string fileName = File.File.FileName;
                long fileSize = File.File.Length;
                string fileExtention = Path.GetExtension(File.File.FileName);

                post.AttachFile(File.Title, command.Id, command.UserId, fileName, fileExtention, File.File.ContentType,
                    fileSize, string.Empty, file);
            }
            try
            {
                posts.Add(post);
            }
            catch (Exception)
            {
                throw;
            }
            return Task.CompletedTask;
        }
    }
}
