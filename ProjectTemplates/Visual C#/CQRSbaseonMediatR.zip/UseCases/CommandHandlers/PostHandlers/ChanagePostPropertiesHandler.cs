﻿using CommandHandling.Abstractions;
using DomainModel;
using System;
using System.IO;
using System.Threading.Tasks;
using $safeprojectname$.Commands.PostCommands;
using $safeprojectname$.Exceptions;
using $safeprojectname$.RepositoryContracts;

namespace $safeprojectname$.CommandHandlers.PostHandlers
{
    public class ChanagePostPropertiesHandler : IHandleCommand<ChanagePostPropertiesCommand>
    {
        private readonly IPostRepository posts;
        //private readonly ICategoryRepository Categories;
        //private readonly IGroupRepository Groups;

        public ChanagePostPropertiesHandler(IPostRepository posts)//, ICategoryRepository Categories, IGroupRepository groups)
        {
            this.posts = posts;
            //this.Categories = Categories;
            //this.Groups = groups;
        }

        public Task Handle(ChanagePostPropertiesCommand command)
        {
            //if (command.CategoryId != null)
            //    if (Categories.Find(command.CategoryId.Value) == null)
            //        throw new NotFoundException("دسته بندی پیدا نشد.");

            /////Karani
            //if (command.GroupId != null)
            //    if (Groups.GetById(command.GroupId.Value) == null)
            //        throw new NotFoundException("گروه پیدا نشد.");

            //if (command.SubGroupId != null)
            //    if (!Groups.DoesSubGroupExist(command.GroupId.Value, command.SubGroupId.Value))
            //        throw new NotFoundException("زیرگروه پیدا نشد.");
            /////Karani


            if (command.IsDraft == true && command.IsPrivate == true)
                throw new ForbiddenException("پست خصوصی نمی تواند به صورت پیش نویس ذخیره شود.");

            Post post = posts.Find(command.Id);
            if (post == null)
                throw new NotFoundException("پست پیدا نشد.");

            if (post.UserId != command.UserId)
                throw new ForbiddenException("کاربر مجاز به تغییر پست نیست.");

            if (post.IsDraft && command.IsPrivate)
                throw new ForbiddenException("پست پیش نویس را نمی توانید به حالت خصوصی تغییر دهید.");

            if (!post.IsDraft && command.IsDraft)
                throw new ForbiddenException("پست منتشر شده را نمی توانید به حالت پیش نویس تغییر دهید.");

            if (post.LogicalDelete)
                throw new ForbiddenException("امکان ویرایش پست حذف شده وجود ندارد.");

            post.ChangePostProperties(command.CategoryId, command.PostTitle, command.PostContent, command.Tags, command.IsPrivate,
                command.IsDraft, command.GroupId, command.SubGroupId);

            foreach (PostAttachmentFileDataStructure File in command.AttachmentList)
            {
                using Stream stream = File.File.OpenReadStream();
                BinaryReader reader = new(stream);
                byte[] file = reader.ReadBytes(Convert.ToInt32(File.File.Length));
                string fileName = File.File.FileName;
                long fileSize = File.File.Length;
                string fileExtention = Path.GetExtension(File.File.FileName);

                post.AttachFile(File.Title, command.Id,
                    command.UserId, fileName, fileExtention, File.File.ContentType, fileSize, string.Empty, file);
            }

            foreach (long postAttachmentIds in command.DeletedFiles)
                post.DetachFile(postAttachmentIds);

            try
            {
                posts.Update(post);
            }
            catch (Exception)
            {
                throw;
            }
            return Task.CompletedTask;
        }
    }
}
