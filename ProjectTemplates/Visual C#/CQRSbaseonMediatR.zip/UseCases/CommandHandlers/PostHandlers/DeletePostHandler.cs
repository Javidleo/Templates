﻿using CommandHandling.Abstractions;
using DomainModel;
using System.Threading.Tasks;
using $safeprojectname$.Commands.PostCommands;
using $safeprojectname$.Exceptions;
using $safeprojectname$.RepositoryContracts;

namespace $safeprojectname$.CommandHandlers.PostHandlers
{
    public class DeletePostHandler : IHandleCommand<DeletePostCommand>
    {
        readonly IPostRepository Posts;
        public DeletePostHandler(IPostRepository Posts)
        => this.Posts = Posts;

        public Task Handle(DeletePostCommand command)
        {
            Post post = Posts.Find(command.Id);
            if (post == null)
                throw new NotFoundException("پست پیدا نشد.");

            if (post.IsDraft)
            {
                post.DeletePost();
                Posts.Delete(post);
            }
            else
            {
                post.LogicalDeletePost(true);
                Posts.Update(post);
            }
            return Task.CompletedTask;
        }
    }
}
