﻿using CommandHandling.Abstractions;

namespace $safeprojectname$.Commands.PostCommands
{
    public record DeletePostCommand(long Id) : Acommand(Id)
    {
        public static DeletePostCommand Create(long Id)
        => new(Id);
    }
}
