﻿using CommandHandling.Abstractions;
using System;
using System.Collections.Generic;
using $safeprojectname$.Exceptions;

namespace $safeprojectname$.Commands.PostCommands
{
    public record PostCommand(string PostTitle, string PostContent, long? CategoryId, Guid UserId,
        string Tags, bool IsPrivate, bool IsDraft, long? GroupId, long? SubGroupId, List<PostAttachmentFileDataStructure> AttachmentList) : Acommand(0)
    {
        public static PostCommand Create(string PostTitle, string PostContent, long? CategoryId, Guid UserId,
            string Tags, bool IsPrivate, bool IsDraft, long? GroupId, long? SubGroupId, List<PostAttachmentFileDataStructure> NewAttachmentList)
        {
            if (PostTitle.Trim().Length == 0)
                throw new BadRequestException("PostTitle must be not null and empty.");

            if (PostContent.Trim().Length == 0)
                throw new BadRequestException("PostContent must be not null and empty.");

            return new PostCommand(PostTitle, PostContent, CategoryId, UserId, Tags, IsPrivate, IsDraft, GroupId, SubGroupId, NewAttachmentList);
        }
    }
}
