﻿namespace KnowledgeManagementAPI.DTOs.Post
{
    public class FileInfo
    {
        public string Title { get; set; }

        public string FileName { get; set; }
    }
}
