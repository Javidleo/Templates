﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace KnowledgeManagementAPI.DTOs.IdentityDTOs
{
    public class KillUserSessionsDto
    {
        public string userGuid { get; set; }
    }
}
