﻿using DataSource;
using Microsoft.Extensions.DependencyInjection;
using ReadModels;
using DataAccess;
using UseCases.RepositoryContracts;
using DataAccess.Repositories;
using CommandHandling.MediatRAdopter;
using QueryHandling.MediatRAdopter;
using UseCases.Commands.PostCommands;
using ReadModels.Query.PostQueries;
using UseCases.CommandHandlers.PostHandlers;


namespace KnowledgeManagementAPI
{
    public static class IOCConfig
    {
        public static void AddApplicationServices(this IServiceCollection services)
        {
            //context
            services.AddScoped<ReadAndWriteDbContext>();
            services.AddScoped<IWriteDbContext>(x => x.GetService<ReadAndWriteDbContext>());
            services.AddScoped<IReadDbContext>(x => x.GetService<ReadAndWriteDbContext>());
            services.AddScoped<IUnitOfWork>(x => x.GetService<ReadAndWriteDbContext>());

            //Repositories
            services.AddTransient<IPostRepository, PostRepository>();
            // commands
            services.AddMessageHandlers();
            services.AddStation<PostCommand, LoggingStation<PostCommand>>();
            //services.AddStation<AddEtebarDorehCommand, LoggingStation<AddEtebarDorehCommand>>();
            services.AddScoped<Filters.UnitOfWorkFilter>();


            //EventHandling.MediatRAdopter.MediatRServiceConfiguration.WrapEventHandler<ProvinceAddedProjector, ProvinceAdded>(services);
            //services.AddEventHandlersFromAssembly<ProvinceAddedProjector>();
        }

        static void AddMessageHandlers(this IServiceCollection services)
        {
            services.AddCommandHandlersFromAssembly<PostHandler>();
            services.AddQueryHandlersFromAssembly<GetPostListQuery>();
            //services.AddEventHandlersFromAssembly(Assembly.GetAssembly(typeof(TeamDefinedReactor))
            //                                     , Assembly.GetAssembly(typeof(TeamListProjector))
            //                                     );
        }
    }
}
