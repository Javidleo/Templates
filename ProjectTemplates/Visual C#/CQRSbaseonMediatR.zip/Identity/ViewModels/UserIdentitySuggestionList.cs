﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace $safeprojectname$.ViewModels
{
    public class UserIdentitySuggestionList
    {
        public List<string> SuggestionList { get; set; }
    }
}
