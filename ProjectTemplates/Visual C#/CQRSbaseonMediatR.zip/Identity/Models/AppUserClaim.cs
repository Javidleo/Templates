﻿using Microsoft.AspNetCore.$safeprojectname$;

namespace $safeprojectname$.Models
{
    public class AppUserClaim : IdentityUserClaim<string>
    {
    }
}
