﻿using Microsoft.AspNetCore.$safeprojectname$;

namespace $safeprojectname$.Models
{
    public class AppUserLogin : IdentityUserLogin<string>
    {
    }
}
