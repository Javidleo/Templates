﻿using Microsoft.AspNetCore.$safeprojectname$;

namespace $safeprojectname$.Models
{
    public class AppUserToken : IdentityUserToken<string>
    {
    }
}
