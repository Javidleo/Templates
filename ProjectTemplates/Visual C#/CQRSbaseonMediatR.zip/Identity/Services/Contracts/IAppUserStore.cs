﻿namespace $safeprojectname$.Services.Contracts
{
    public interface IAppUserStore
    {
    }
}