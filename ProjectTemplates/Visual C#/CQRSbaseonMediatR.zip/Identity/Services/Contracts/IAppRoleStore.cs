﻿namespace $safeprojectname$.Services.Contracts
{
    public  interface IAppRoleStore
    {
    }
}