﻿using $safeprojectname$.Models;
using Microsoft.AspNetCore.$safeprojectname$;
using System.Threading.Tasks;


namespace $safeprojectname$.Services.Contracts
{
    public interface IAppSignInManager
    {
        #region baseClass
        UserManager<AppUser> UserManager { get; set; }
        Task<SignInResult> PasswordSignInAsync(string userName, string password, bool isPersistent, bool lockoutOnFailure);
        Task<SignInResult> PasswordSignInAsync(AppUser user, string password, bool isPersistent, bool lockoutOnFailure);
        #endregion
    }
}
