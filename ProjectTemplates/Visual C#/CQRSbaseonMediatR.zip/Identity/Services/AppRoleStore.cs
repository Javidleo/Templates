﻿using $safeprojectname$.DataSource;
using $safeprojectname$.Models;
using $safeprojectname$.Services.Contracts;
using Microsoft.AspNetCore.$safeprojectname$;
using Microsoft.AspNetCore.$safeprojectname$.EntityFrameworkCore;

namespace $safeprojectname$.Services
{
    public class AppRoleStore : RoleStore<AppRole,ApplicationDbContext,string,AppUserRole,AppRoleClaim> , IAppRoleStore
    {
        public AppRoleStore(IUnitOfWork unitOfWork, IdentityErrorDescriber errorDescriber = null)
            : base((ApplicationDbContext)unitOfWork, errorDescriber)
        { }

    }
}
