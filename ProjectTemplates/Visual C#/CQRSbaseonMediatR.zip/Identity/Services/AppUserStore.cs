﻿using $safeprojectname$.DataSource;
using $safeprojectname$.Models;
using $safeprojectname$.Services.Contracts;
using Microsoft.AspNetCore.$safeprojectname$;
using Microsoft.AspNetCore.$safeprojectname$.EntityFrameworkCore;

namespace $safeprojectname$.Services
{
    public class AppUserStore : UserStore<AppUser,AppRole,ApplicationDbContext,string,AppUserClaim,AppUserRole,AppUserLogin,AppUserToken,AppRoleClaim>,IAppUserStore
    {
        public AppUserStore(IUnitOfWork unitOfWork, IdentityErrorDescriber describer=null) : base((ApplicationDbContext)unitOfWork,describer)
        { }
    }
}
