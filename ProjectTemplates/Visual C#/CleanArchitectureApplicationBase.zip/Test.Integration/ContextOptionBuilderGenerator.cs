﻿using $fileinputname$DataAccess;
using Microsoft.EntityFrameworkCore;

namespace $safeprojectname$
{
    public class ContextOptionBuilderGenerator
    {
        public DbContextOptionsBuilder<Context> Build()
        {
            var optionBuilder = new DbContextOptionsBuilder<Context>();
            optionBuilder.UseSqlServer("Server=DESKTOP-MONHQ70;Database=bookdb;Trusted_Connection=True;");
            return optionBuilder;
        }
    }
}
