﻿using Microsoft.EntityFrameworkCore;

namespace $safeprojectname$;

public class $fileinputname$Context : DbContext
{
    public $fileinputname$Context() { }
    public$fileinputname$Context(DbContextOptions<$fileinputname$Context> option) : base(option) { }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        base.OnConfiguring(optionsBuilder);
    }
    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
       
    }
}
