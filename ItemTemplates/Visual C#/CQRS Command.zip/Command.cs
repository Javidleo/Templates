﻿using CommandHandling.Abstractions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $rootnamespace$
{
    public record $safeitemname$() : Acommand(0)
    {
        public static $safeitemname$ Create()
        {
            throw new NotImplementedException();
        }
    }
}
