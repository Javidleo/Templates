﻿using QueryHandling.Abstractions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReadModels.QueryHandlers.$fileinputname$QueryHandlers
{
    public class $safeitemname$: IHandleQuery<$fileinputname$Query, $fileinputname$ViewModel>
    {
        public $safeitemname$() { }
        
        public Task<$fileinputname$ViewModel> Handle($fileinputname$Query query)
        {
            throw new NotImplementedException();
        }
    }
}
