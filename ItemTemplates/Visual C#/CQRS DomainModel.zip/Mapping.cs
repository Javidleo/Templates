﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataSource.Mapping
{
    public class $safeitemname$ : IEntityTypeConfiguration<$fileinputname$>
    {
        public void Configure(EntityTypeBuilder<$fileinputname$> builder)
        {
            throw new NotImplementedException();
        }
    }
}
