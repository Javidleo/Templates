﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomainModel
{
    public class $safeitemname$
    {
        public int Id { get; private set; }

        $if$($type1$ == ifNullOrEmpty)
            if(!string.IsNullOrEmpty($type1$))
        public $type1$ $value1$ {get; private set;}
        $endif$

        private $safeitemname$() { }

        public static $safeitemname$ Create() 
        {
            throw new NotImplementedException();
        }
    }
}
