﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReadModels.Queries.$fileinputname$Queries
{
    public record $safeitemname$(): Query<$fileinputname$ViewModel>;
}
