﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UseCases.RepositoryContracts
{
    public interface $safeitemname$
    {
        public void Add($fileinputname$ obj);

        public void Update($fileinputname$ obj);

        public void Delete($fileinputname$ obj);
    }
}
