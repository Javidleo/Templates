﻿using CommandHandling.Abstractions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UseCases.CommandHandlers.$fileinputname$CommandHandlers
{
    public class $safeitemname$: IHandleCommand<$fileinputname$Command>
    {
        public Task Handle($fileinputname$Command command)
        {
            throw new NotImplementedException();
        }
    }
}
