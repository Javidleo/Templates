﻿using QueryHandling.Abstractions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $rootnamespace$
{
    public class $safeitemname$: IHandleQuery<$fileinputname$Query, $fileinputname$ViewModel>
    {
        public $safeitemname$() { }
        
        public Task<$fileinputname$ViewModel> Handle($fileinputname$Query query)
        {
            throw new NotImplementedException();
        }
    }
}
